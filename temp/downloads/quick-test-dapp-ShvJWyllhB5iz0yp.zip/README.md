# Quick Test dApp

## Project Description
A quick test to verify the payment and generation flow works correctly in a Solana-based dApp.

## Technical Requirements
- Next.js 14 with App Router
- TypeScript with strict mode
- Solana wallet integration
- Tailwind CSS for styling
- Responsive design
- Clean, documented code
- Error handling and loading states
- Type safety throughout

## Setup & Running
- Install dependencies with `npm install`
- Start the development server with `npm run dev`

## Contributing
Feel free to contribute to the project by submitting a pull request.

## License
MIT