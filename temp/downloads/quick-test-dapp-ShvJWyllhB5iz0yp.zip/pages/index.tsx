import { useWallet } from '@solana/wallet-adapter-react'
import { FC, useCallback } from 'react'

const Home: FC = () => {
  const { connect, connected } = useWallet()

  const handleConnect = useCallback(async () => {
    try {
      await connect()
    } catch (error) {
      console.error('Failed to connect to wallet:', error)
    }
  }, [connect])

  return (
    <div className='flex flex-col items-center justify-center min-h-screen py-2'>
      <main className='flex flex-col items-center justify-center w-full flex-1 px-20 text-center'>
        {!connected ? (
          <button
            className='px-4 py-2 font-bold text-white bg-blue-500 rounded hover:bg-blue-700'
            onClick={handleConnect}
          >
            Connect Wallet
          </button>
        ) : (
          <p>Wallet Connected</p>
        )}
      </main>
    </div>
  )
}

export default Home
