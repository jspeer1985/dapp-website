## Optik Ecosystem

The Optik Ecosystem is a full-stack, on-chain infrastructure platform designed to enable non-technical and technical users alike to launch production-ready blockchain projects with real economic depth.

### Features

- Solana wallet integration
- SPL token minting functionality
- Token metadata setup

### Getting Started

First, install the dependencies:

```
npm install
```

Next, run the development server:

```
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

### Environment Variables

Copy `.env.local.example` to `.env.local` and update the values accordingly.

### Build

To build the project for production:

```
npm run build
```

### Deploy

Deploy it on a platform like Vercel or Netlify.