import type { NextPage } from 'next';
import Head from 'next/head';
import { useWallet } from '../contexts/WalletContext';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import '@solana/wallet-adapter-react-ui/styles.css';

const Home: NextPage = () => {
  const { publicKey } = useWallet();

  return (
    <div>
      <Head>
        <title>Optik Ecosystem</title>
        <meta name="description" content="Launch production-ready blockchain projects" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main>
        <h1>Welcome to Optik Ecosystem</h1>
        <WalletMultiButton />
        {publicKey && <p>Connected wallet address: {publicKey.toBase58()}</p>}
      </main>
    </div>
  );
};

export default Home;