# Test Starter Project

## Project Description
Automated test for Starter tier. This is a comprehensive end-to-end test to verify payment processing and dApp generation functionality.

### Features
- Next.js 14 with App Router
- TypeScript with strict mode
- Solana wallet integration
- Tailwind CSS for styling
- Responsive design

### Getting Started
First, run the development server:
```
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

### Learn More
To learn more about Next.js, take a look at the following resources:
- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.