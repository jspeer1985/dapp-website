import type { NextPage } from 'next';
import Head from 'next/head';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';

const Home: NextPage = () => {
  const { publicKey } = useWallet();

  return (
    <div>
      <Head>
        <title>Test Starter Project</title>
        <meta name="description" content="Automated test for Starter tier." />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <main className='container mx-auto text-center'>
        <h1 className='text-4xl font-bold my-8'>Welcome to Test Starter Project</h1>
        <WalletMultiButton className='mx-auto' />
        {publicKey && <p>Your wallet address: {publicKey.toString()}</p>}
      </main>
    </div>
  );
};

export default Home;