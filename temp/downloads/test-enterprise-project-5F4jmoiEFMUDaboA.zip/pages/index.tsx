import { useWallet } from '@solana/wallet-adapter-react';
import { FC } from 'react';
import Head from 'next/head';
import styles from '../styles/Home.module.css';

const Home: FC = () => {
  const { connected } = useWallet();

  return (
    <div className={styles.container}>
      <Head>
        <title>Test Enterprise Project</title>
        <meta name="description" content="Automated test for Enterprise tier. This is a comprehensive end-to-end test to verify payment processing and dApp generation functionality." />
      </Head>

      <main className={styles.main}>
        {connected ? (
          <p>Wallet Connected</p>
        ) : (
          <p>Please connect your wallet</p>
        )}
      </main>
    </div>
  );
};

export default Home;
