## Test Enterprise Project

This project is an automated test for Enterprise tier, focusing on verifying payment processing and dApp generation functionality using Solana blockchain.

### Features

- Next.js 14 with App Router
- TypeScript with strict mode
- Solana wallet integration
- Responsive design using Tailwind CSS

### Getting Started

1. Clone the repository
2. Install dependencies with `npm install`
3. Copy `.env.local.example` to `.env.local` and fill in your Solana network details
4. Run the development server with `npm run dev`

Visit http://localhost:3000 to view your application.
