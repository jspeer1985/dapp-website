import { FC, ReactNode } from 'react';
import Head from 'next/head';

interface LayoutProps {
  children: ReactNode;
}

const Layout: FC<LayoutProps> = ({ children }) => (
  <div>
    <Head>
      <title>Test Professional Project</title>
      <meta name='description' content='Automated test for Professional tier.' />
      <link rel='icon' href='/favicon.ico' />
    </Head>
    <main>{children}</main>
  </div>
);

export default Layout;