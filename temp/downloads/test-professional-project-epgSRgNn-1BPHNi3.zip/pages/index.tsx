import { FC } from 'react';
import { useWallet } from '../contexts/WalletContext';
import Layout from '../components/Layout';

const Home: FC = () => {
  const { walletAddress, connectWallet } = useWallet();

  return (
    <Layout>
      <div className='container mx-auto text-center'>
        {!walletAddress ? (
          <button
            onClick={connectWallet}
            className='px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700 transition duration-300'>
            Connect Wallet
          </button>
        ) : (
          <p>Wallet Address: {walletAddress}</p>
        )}
      </div>
    </Layout>
  );
};

export default Home;