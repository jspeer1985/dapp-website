# Test Professional Project

This project is an automated test for Professional tier, focusing on verifying payment processing and dApp generation functionality. It integrates with Solana blockchain for wallet interactions and uses Next.js 14 with TypeScript for the frontend.

## Features

- Next.js 14 with App Router
- TypeScript with strict mode
- Solana wallet integration
- Tailwind CSS for styling
- Responsive design
- Clean, documented code
- Error handling and loading states
- Type safety throughout

## Setup

1. Clone the repository.
2. Install dependencies with `npm install`.
3. Copy `.env.local.example` to `.env.local` and update the environment variables.
4. Run the development server with `npm run dev`.

Visit `http://localhost:3000` to view the application.