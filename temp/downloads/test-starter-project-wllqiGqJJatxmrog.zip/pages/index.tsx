import type { NextPage } from 'next';
import Head from 'next/head';
import { useWallet } from '../hooks/useWallet';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';

const Home: NextPage = () => {
  const { walletAddress } = useWallet();

  return (
    <div className='container mx-auto px-4'>
      <Head>
        <title>Test Starter Project</title>
      </Head>
      <main className='mt-10 text-center'>
        <h1 className='text-xl'>Welcome to Test Starter Project</h1>
        <p>{walletAddress ? `Wallet Address: ${walletAddress}` : 'Connect your wallet'}</p>
        <WalletMultiButton />
      </main>
    </div>
  );
};

export default Home;