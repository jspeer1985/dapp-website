## Test Starter Project

### Description
Automated test for Starter tier. This is a comprehensive end-to-end test to verify payment processing and dApp generation functionality.

### Features
- Next.js 14 with App Router
- TypeScript with strict mode
- Solana wallet integration
- Tailwind CSS for styling
- Responsive design

### Setup
1. Clone the repository.
2. Install dependencies with `npm install`.
3. Copy `.env.local.example` to `.env.local` and update with your Solana network details.
4. Run the development server with `npm run dev`.

Visit `http://localhost:3000` to view the application.