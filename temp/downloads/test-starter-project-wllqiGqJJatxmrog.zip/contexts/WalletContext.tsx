import { createContext, ReactNode, useState, useEffect } from 'react';
import { useConnection, useWallet as useSolanaWallet } from '@solana/wallet-adapter-react';

interface WalletContextType {
  walletAddress: string | null;
}

export const WalletContext = createContext<WalletContextType | undefined>(undefined);

export const WalletProvider = ({ children }: { children: ReactNode }) => {
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const { publicKey } = useSolanaWallet();

  useEffect(() => {
    if (publicKey) {
      setWalletAddress(publicKey.toString());
    } else {
      setWalletAddress(null);
    }
  }, [publicKey]);

  return (
    <WalletContext.Provider value={{ walletAddress }}>
      {children}
    </WalletContext.Provider>
  );
};