import { FC } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { Button } from '@solana/wallet-adapter-react-ui';
require('@solana/wallet-adapter-react-ui/styles.css');

const Home: FC = () => {
  const { wallet, connected } = useWallet();

  return (
    <div className='container mx-auto text-center py-10'>
      <h1 className='text-3xl font-bold'>Welcome to Test Professional Project</h1>
      <p className='py-4'>This is a comprehensive end-to-end test to verify payment processing and dApp generation functionality.</p>
      <div>
        {connected ? (
          <p>Welcome, {wallet?.adapter.name} user!</p>
        ) : (
          <Button>Connect Wallet</Button>
        )}
      </div>
    </div>
  );
};

export default Home;